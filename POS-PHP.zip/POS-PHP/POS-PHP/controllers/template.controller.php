<?php

class ControllerTemplate{

	static public function ctrTemplate(){
		include "views/template.php";
	}
}