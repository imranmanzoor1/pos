<footer class="main-footer">

	<strong>&copy; 2022 - Point of Sale System in PHP</strong>
	
	All rights reserved

</footer>