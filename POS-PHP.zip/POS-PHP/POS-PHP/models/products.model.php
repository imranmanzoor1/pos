<?php

require_once 'connection.php';

class ProductsModel {
    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    SHOWING PRODUCTS
    =============================================*/

    static public function mdlShowProducts($table, $item, $value, $order) {
        $connection = new Connection(); // Instantiate Connection
        $db = $connection->connect(); // Call connect() on the instance

        if ($item != null) {
            $stmt = $db->prepare("SELECT * FROM $table WHERE $item = :$item ORDER BY id DESC");
            $stmt->bindParam(":".$item, $value, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetch();
        } else {
            $stmt = $db->prepare("SELECT * FROM $table ORDER BY $order DESC");
            $stmt->execute();
            return $stmt->fetchAll();
        }
    }

    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    ADDING PRODUCT
    ============================================*/
    static public function mdlAddProduct($table, $data) {
        $connection = new Connection();
        $db = $connection->connect();

        $stmt = $db->prepare("INSERT INTO $table(idCategory, code, description, image, stock, buyingPrice, sellingPrice) VALUES (:idCategory, :code, :description, :image, :stock, :buyingPrice, :sellingPrice)");

        $stmt->bindParam(":idCategory", $data["idCategory"], PDO::PARAM_INT);
        $stmt->bindParam(":code", $data["code"], PDO::PARAM_STR);
        $stmt->bindParam(":description", $data["description"], PDO::PARAM_STR);
        $stmt->bindParam(":image", $data["image"], PDO::PARAM_STR);
        $stmt->bindParam(":stock", $data["stock"], PDO::PARAM_STR);
        $stmt->bindParam(":buyingPrice", $data["buyingPrice"], PDO::PARAM_STR);
        $stmt->bindParam(":sellingPrice", $data["sellingPrice"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    EDITING PRODUCT
    ============================================*/
    static public function mdlEditProduct($table, $data) {
        $connection = new Connection();
        $db = $connection->connect();

        $stmt = $db->prepare("UPDATE $table SET idCategory = :idCategory, description = :description, image = :image, stock = :stock, buyingPrice = :buyingPrice, sellingPrice = :sellingPrice WHERE code = :code");

        $stmt->bindParam(":idCategory", $data["idCategory"], PDO::PARAM_INT);
        $stmt->bindParam(":code", $data["code"], PDO::PARAM_STR);
        $stmt->bindParam(":description", $data["description"], PDO::PARAM_STR);
        $stmt->bindParam(":image", $data["image"], PDO::PARAM_STR);
        $stmt->bindParam(":stock", $data["stock"], PDO::PARAM_STR);
        $stmt->bindParam(":buyingPrice", $data["buyingPrice"], PDO::PARAM_STR);
        $stmt->bindParam(":sellingPrice", $data["sellingPrice"], PDO::PARAM_STR);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    DELETING PRODUCT
    ============================================*/
    static public function mdlDeleteProduct($table, $data) {
        $connection = new Connection();
        $db = $connection->connect();

        $stmt = $db->prepare("DELETE FROM $table WHERE id = :id");
        $stmt->bindParam(":id", $data, PDO::PARAM_INT);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    UPDATE PRODUCT
    ============================================*/
    static public function mdlUpdateProduct($table, $item1, $value1, $value) {
        $connection = new Connection();
        $db = $connection->connect();

        $stmt = $db->prepare("UPDATE $table SET $item1 = :$item1 WHERE id = :id");
        $stmt->bindParam(":".$item1, $value1, PDO::PARAM_STR);
        $stmt->bindParam(":id", $value, PDO::PARAM_STR);

        if ($stmt->execute()) {
            return "ok";
        } else {
            return "error";
        }
    }

    /* --LOG ON TO codeastro.com FOR MORE PROJECTS-- */
    /*=============================================
    SHOW ADDING OF THE SALES
    ============================================*/
    static public function mdlShowAddingOfTheSales($table) {
        $connection = new Connection();
        $db = $connection->connect();

        $stmt = $db->prepare("SELECT SUM(sales) as total FROM $table");
        $stmt->execute();

        return $stmt->fetch();
    }
}
